using System;
using System.Collections.Generic;
using System.Linq;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Web.Infrastructure
{
    public static class SampleCatalogSeeder
    {
        private sealed class CatalogGroup
        {
            public string Category;
            public string[] Products;
            public string[] Sizes;
            public string[] Colors;
            public string[] Images;
        }

        public static void Seed(ApplicationDbContext db)
        {
            var groups = BuildCatalog();
            foreach (var group in groups)
                if (!db.Categories.Any(c => c.Name == group.Category))
                    db.Categories.Add(new Category { Name = group.Category });
            db.SaveChanges();

            int sequence = 0;
            foreach (var group in groups)
            {
                var category = db.Categories.Single(c => c.Name == group.Category);
                foreach (var name in group.Products)
                {
                    sequence++;
                    var product = db.Products.SingleOrDefault(p => p.Name == name);
                    if (product == null)
                    {
                        product = new Product
                        {
                            Name = name,
                            Description = BuildDescription(name, group.Category),
                            Price = PriceFor(sequence, group.Category),
                            ImageUrl = group.Images[(sequence - 1) % group.Images.Length],
                            CategoryId = category.CategoryId,
                            IsFeatured = sequence <= 12 || sequence % 9 == 0,
                            IsActive = true
                        };
                        db.Products.Add(product);
                        db.SaveChanges();
                    }
                    // Refresh sample-catalog image URLs on existing rows as well as newly seeded products.
                    // This fixes older databases that were seeded with one shared image per category.
                    var correctImage = group.Images[(sequence - 1) % group.Images.Length];
                    if (product.ImageUrl != correctImage)
                    {
                        product.ImageUrl = correctImage;
                        db.SaveChanges();
                    }
                    if (!db.ProductVariants.Any(v => v.ProductId == product.ProductId))
                    {
                        if (group.Sizes.Length == 1)
                        {
                            db.ProductVariants.Add(new ProductVariant { ProductId = product.ProductId, Size = group.Sizes[0], Color = group.Colors[sequence % group.Colors.Length], StockQuantity = 8 + sequence % 24 });
                        }
                        else
                        {
                            for (int i = 0; i < group.Sizes.Length; i++)
                                db.ProductVariants.Add(new ProductVariant { ProductId = product.ProductId, Size = group.Sizes[i], Color = group.Colors[sequence % group.Colors.Length], StockQuantity = 6 + ((sequence + i * 3) % 22) });
                        }
                    }
                }
                db.SaveChanges();
            }
        }

        private static decimal PriceFor(int n, string category)
        {
            int basePrice = category == "Beauty & Care" ? 399 : category == "Kids" ? 599 : category == "Footwear" ? 1499 : category == "Bags & Luggage" ? 1299 : 899;
            return basePrice + (n * 137 % 2600);
        }

        private static string BuildDescription(string name, string category)
        {
            return name + " from our " + category + " edit. Thoughtfully selected for expressive everyday style, comfort and versatile wardrobe pairing.";
        }

        private static string[] Images(params string[] photoIds)
        {
            return photoIds.Select(id => "https://images.unsplash.com/photo-" + id + "?auto=format&fit=crop&w=900&q=85").ToArray();
        }

        private static List<CatalogGroup> BuildCatalog()
        {
            return new List<CatalogGroup>
            {
                new CatalogGroup { Category="Women", Sizes=new[]{"XS","S","M","L","XL"}, Colors=new[]{"Black","Ivory","Coral","Sage","Blue"}, Images=Images("1515886657613-9f3515b0c78f","1529139574466-a303027c1d8b","1539109136881-3be0616acf4b","1503342217505-b0a15ec3261c","1483985988355-763728e1935b","1490481651871-ab68de25d43d","1525507119028-ed4c629a60a3","1544441893-675973e31985","1591047139829-d91aecb6caea","1523381210434-271e8be1f52b","1551488831-00ddcb6c6bd3","1576566588028-4147f3842f27","1578587018452-892bacefd3f2","1583743814966-8936f37f4678","1627225924765-552d49cf47ad","1521572163474-6864f9cf17ab","1524504388940-b1c1722653e1","1543076447-215ad9ba6923","1566206091558-7ec31c2b6d59","1551803091-e20673f15770"), Products=new[]{
                    "Sculpted Linen Blazer","Everyday Ribbed Tank","Satin Evening Top","Relaxed Wide-Leg Trousers","Weekend Denim Jacket","Soft Knit Cardigan","Floral Midi Dress","Tailored Co-ord Set","Classic Wrap Dress","Textured Cotton Shirt","Pleated Midi Skirt","Essential Straight Jeans","Cropped Utility Jacket","Draped Occasion Blouse","Luxe Lounge Set","Printed Summer Maxi","Structured Waistcoat","Soft Touch Leggings","Button-Front Mini Dress","Statement Knit Sweater" } },
                new CatalogGroup { Category="Men", Sizes=new[]{"S","M","L","XL","XXL"}, Colors=new[]{"Black","White","Navy","Olive","Stone"}, Images=Images("1516257984-b1b4d707412e","1519085360753-af0119f7cbe7","1523398002811-999ca8dec234","1520975916090-3105956dac38","1618354691373-d851c5c3a990","1603252109303-2751441dd157","1521572163474-6864f9cf17ab","1515886657613-9f3515b0c78f","1598033129183-c4f50c736f10","1516826957135-700dedea698c","1617137968427-85924c800a22","1620799140408-edc6dcb6d633","1551028719-00167b16eac5","1512436991641-6745cdb1723f","1529139574466-a303027c1d8b","1544441893-675973e31985","1503342217505-b0a15ec3261c","1551488831-00ddcb6c6bd3","1576566588028-4147f3842f27","1525507119028-ed4c629a60a3"), Products=new[]{
                    "Premium Heavyweight Tee","Oxford Button-Down Shirt","Relaxed Chino Trousers","Classic Denim Overshirt","Textured Polo Shirt","Tailored Casual Blazer","Everyday Crew Sweatshirt","Straight Fit Jeans","Lightweight Bomber Jacket","Linen Resort Shirt","Utility Cargo Pants","Merino Blend Sweater","Minimal Track Jacket","Smart Casual Shirt","Weekend Drawstring Shorts","Zip-Neck Knit Top","Heritage Check Shirt","Performance Training Tee","Relaxed Fit Hoodie","Modern Pleated Trousers" } },
                new CatalogGroup { Category="Footwear", Sizes=new[]{"6","7","8","9","10","11"}, Colors=new[]{"White","Black","Tan","Grey"}, Images=Images("1542291026-7eec264c27ff","1728724794795-681832a6afd0","1543163521-1bf539c55dd2","1552346154-21d32810aba3","1560769629-975ec94e6a6f","1525966222134-fcfa99b8ae77","1495555961986-6d4c1ecb7be3","1460353581641-37baddab0fa2","1539185441755-769473a23570","1600185365483-26d7a4cc7519","1549298916-b41d501d3772","1608231387042-66d1773070a5","1551107696-a4b0c5a0d9a2","1514989940723-e8e51635b782","1544441893-675973e31985"), Products=new[]{
                    "Retro Court Sneakers","Everyday Running Shoes","Leather Minimal Trainers","City Walk Loafers","Classic Canvas High-Tops","Chunky Street Sneakers","Suede Weekend Shoes","Minimal Slide Sandals","Everyday Leather Flats","Sport Performance Runners","Urban High-Top Sneakers","Soft Strap Sandals","Classic Penny Loafers","Trail Ready Trainers","Statement Platform Sneakers" } },
                new CatalogGroup { Category="Kids", Sizes=new[]{"2-3Y","4-5Y","6-7Y","8-9Y"}, Colors=new[]{"Blue","Pink","Yellow","Green"}, Images=Images("1519238263530-99bdd11df2ea","1503919005314-30d93d07d823","1519689680058-324335c77eba","1516627145497-ae6968895b74","1519457431-44ccd64a579b","1503454537195-1dcabb73ffb9","1514090458221-65bb69cf63e6","1515886657613-9f3515b0c78f","1529139574466-a303027c1d8b","1503342217505-b0a15ec3261c"), Products=new[]{
                    "Mini Explorer Hoodie","Playday Cotton Tee","Rainbow Stripe Dress","Everyday Jogger Set","Little Weekend Shorts","Soft Knit Cardigan Kids","Graphic Adventure Tee","Easy Pull-On Trousers","Printed Party Dress","Cozy Zip Sweatshirt" } },
                new CatalogGroup { Category="Accessories", Sizes=new[]{"One Size"}, Colors=new[]{"Black","Tan","Silver","Gold","Multi"}, Images=Images("1523275335684-37898b6baf30","1511499767150-a48a237f0083","1611652022419-a9419f74343d","1617038220319-276d3cfab638","1611591437281-460bfbe1220a","1535632066927-ab7c9ab60908","1573408301185-9146fe634ad0","1584917865442-de89df76afd3","1601924994987-69e26d50dc26","1490481651871-ab68de25d43d","1503342217505-b0a15ec3261c","1529139574466-a303027c1d8b","1618354691373-d851c5c3a990","1617137968427-85924c800a22","1620799140408-edc6dcb6d633"), Products=new[]{
                    "Sculptural Metal Earrings","Everyday Leather Belt","Layered Chain Necklace","Classic Square Sunglasses","Minimal Analog Watch","Soft Knit Beanie","Textured Baseball Cap","Silk Touch Scarf","Statement Cuff Bracelet","Everyday Card Holder","Modern Hair Clip Set","Compact Travel Umbrella","Premium Leather Wallet","Pearl Detail Earrings","Minimal Pendant Necklace" } },
                new CatalogGroup { Category="Beauty & Care", Sizes=new[]{"One Size"}, Colors=new[]{"Natural","Rose","Clear"}, Images=Images("1608248543803-ba4f8c70ae0b","1721403396830-d290f04c08a4","1596462502278-27bfdc403348","1601049541289-9b1b7bbbfe19","1598440947619-2c35fc9aa908","1611930022073-b7a4ba5fcccd","1570172619644-dfd03ed5d881","1556229010-6c3f2c9ca5f8","1612817288484-6f916006741a","1596755389378-c31d21fd1273"), Products=new[]{
                    "Daily Glow Face Serum","Hydrating Body Lotion","Velvet Matte Lip Colour","Gentle Foaming Cleanser","Nourish Hair Mask","Daily SPF Moisturizer","Rosewater Face Mist","Soft Touch Hand Cream","Overnight Repair Cream","Fresh Citrus Body Wash" } },
                new CatalogGroup { Category="Bags & Luggage", Sizes=new[]{"One Size"}, Colors=new[]{"Black","Tan","Cream","Olive"}, Images=Images("1548036328-c9fa89d128fa","1590874103328-eac38a683ce7","1584917865442-de89df76afd3","1553062407-98eeb64c6a62","1547949003-9792a18a2601"), Products=new[]{
                    "Everyday Structured Tote","Compact Crossbody Bag","Weekend Travel Duffel","Minimal Laptop Backpack","Soft Shoulder Bag" } },
                new CatalogGroup { Category="Activewear", Sizes=new[]{"XS","S","M","L","XL"}, Colors=new[]{"Black","Lilac","Sage","Blue"}, Images=Images("1518611012118-696072aa579a","1534438327276-14e5300c3a48","1571019613454-1cb2f99b2d8b","1517836357463-d25dfeac3438","1546483875-ad9014c88eba"), Products=new[]{
                    "Studio Sculpt Leggings","Breathable Training Tee","High Support Sports Bra","Lightweight Running Shorts","Performance Zip Jacket" } }
            };
        }
    }
}
