using System;
namespace ShopSphere.Domain.Entities
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public int OrderId { get; set; }
        public string Method { get; set; }
        public PaymentStatus Status { get; set; }
        public string TransactionReference { get; set; }
        public DateTime CreatedUtc { get; set; }
        public virtual Order Order { get; set; }
        public Payment() { CreatedUtc = DateTime.UtcNow; Status = PaymentStatus.Pending; }
    }
}
