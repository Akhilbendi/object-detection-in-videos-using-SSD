using System.ComponentModel.DataAnnotations;
namespace ShopSphere.Domain.Entities
{
    public class Address
    {
        public int AddressId { get; set; }
        public int UserId { get; set; }
        [Required, StringLength(100)] public string RecipientName { get; set; }
        [Required, StringLength(20)] public string Phone { get; set; }
        [Required, StringLength(250)] public string Line1 { get; set; }
        [StringLength(250)] public string Line2 { get; set; }
        [Required, StringLength(80)] public string City { get; set; }
        [Required, StringLength(80)] public string State { get; set; }
        [Required, StringLength(10)] public string PostalCode { get; set; }
        public virtual User User { get; set; }
    }
}
