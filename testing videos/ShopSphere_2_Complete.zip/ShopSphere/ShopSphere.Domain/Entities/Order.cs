using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ShopSphere.Domain.Entities
{
    public class Order
    {
        public int OrderId { get; set; }
        public int UserId { get; set; }
        public int AddressId { get; set; }
        [Required, StringLength(30)] public string OrderNumber { get; set; }
        public DateTime CreatedUtc { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Shipping { get; set; }
        public decimal Total { get; set; }
        public OrderStatus Status { get; set; }
        public virtual User User { get; set; }
        public virtual Address Address { get; set; }
        public virtual ICollection<OrderItem> Items { get; set; }
        public Order() { Items = new HashSet<OrderItem>(); CreatedUtc = DateTime.UtcNow; Status = OrderStatus.Pending; }
    }
}
