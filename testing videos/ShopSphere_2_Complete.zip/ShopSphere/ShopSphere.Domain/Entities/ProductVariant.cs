using System.ComponentModel.DataAnnotations;

namespace ShopSphere.Domain.Entities
{
    public class ProductVariant
    {
        public int ProductVariantId { get; set; }
        public int ProductId { get; set; }
        [Required, StringLength(20)]
        public string Size { get; set; }
        [Required, StringLength(40)]
        public string Color { get; set; }
        [Range(0, 100000)]
        public int StockQuantity { get; set; }
        public virtual Product Product { get; set; }
    }
}
