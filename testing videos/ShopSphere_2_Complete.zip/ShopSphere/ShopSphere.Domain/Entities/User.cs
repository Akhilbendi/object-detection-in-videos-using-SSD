using System;
using System.ComponentModel.DataAnnotations;

namespace ShopSphere.Domain.Entities
{
    public class User
    {
        public int UserId { get; set; }
        [Required, StringLength(100)] public string FullName { get; set; }
        [Required, StringLength(256)] public string Email { get; set; }
        [Required] public string PasswordHash { get; set; }
        [Required, StringLength(20)] public string Role { get; set; }
        public DateTime CreatedUtc { get; set; }
        public bool IsActive { get; set; }
        public User() { CreatedUtc = DateTime.UtcNow; IsActive = true; Role = "Customer"; }
    }
}
