using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ShopSphere.Domain.Entities
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required, StringLength(140)]
        public string Name { get; set; }

        [Required, StringLength(2000)]
        public string Description { get; set; }

        [Range(0.01, 1000000)]
        public decimal Price { get; set; }

        [StringLength(500)]
        public string ImageUrl { get; set; }

        public bool IsFeatured { get; set; }
        public bool IsActive { get; set; }
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public virtual ICollection<ProductVariant> Variants { get; set; }

        public Product() { Variants = new HashSet<ProductVariant>(); IsActive = true; }
    }
}
