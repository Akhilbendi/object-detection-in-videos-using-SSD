using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ShopSphere.Domain.Entities
{
    public class Category
    {
        public int CategoryId { get; set; }

        [Required, StringLength(80)]
        public string Name { get; set; }

        public virtual ICollection<Product> Products { get; set; }
        public Category() { Products = new HashSet<Product>(); }
    }
}
