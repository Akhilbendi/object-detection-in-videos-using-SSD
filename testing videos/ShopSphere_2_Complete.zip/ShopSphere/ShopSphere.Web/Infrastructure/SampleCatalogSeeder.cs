using System;
using System.Collections.Generic;
using System.Linq;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Web.Infrastructure
{
    public static class SampleCatalogSeeder
    {
        private sealed class CatalogGroup
        {
            public string Category;
            public string[] Products;
            public string[] Sizes;
            public string[] Colors;
            public string Image;
        }

        public static void Seed(ApplicationDbContext db)
        {
            var groups = BuildCatalog();
            foreach (var group in groups)
                if (!db.Categories.Any(c => c.Name == group.Category))
                    db.Categories.Add(new Category { Name = group.Category });
            db.SaveChanges();

            int sequence = 0;
            foreach (var group in groups)
            {
                var category = db.Categories.Single(c => c.Name == group.Category);
                foreach (var name in group.Products)
                {
                    sequence++;
                    var product = db.Products.SingleOrDefault(p => p.Name == name);
                    if (product == null)
                    {
                        product = new Product
                        {
                            Name = name,
                            Description = BuildDescription(name, group.Category),
                            Price = PriceFor(sequence, group.Category),
                            ImageUrl = group.Image,
                            CategoryId = category.CategoryId,
                            IsFeatured = sequence <= 12 || sequence % 9 == 0,
                            IsActive = true
                        };
                        db.Products.Add(product);
                        db.SaveChanges();
                    }
                    if (!db.ProductVariants.Any(v => v.ProductId == product.ProductId))
                    {
                        if (group.Sizes.Length == 1)
                        {
                            db.ProductVariants.Add(new ProductVariant { ProductId = product.ProductId, Size = group.Sizes[0], Color = group.Colors[sequence % group.Colors.Length], StockQuantity = 8 + sequence % 24 });
                        }
                        else
                        {
                            for (int i = 0; i < group.Sizes.Length; i++)
                                db.ProductVariants.Add(new ProductVariant { ProductId = product.ProductId, Size = group.Sizes[i], Color = group.Colors[sequence % group.Colors.Length], StockQuantity = 6 + ((sequence + i * 3) % 22) });
                        }
                    }
                }
                db.SaveChanges();
            }
        }

        private static decimal PriceFor(int n, string category)
        {
            int basePrice = category == "Beauty & Care" ? 399 : category == "Kids" ? 599 : category == "Footwear" ? 1499 : category == "Bags & Luggage" ? 1299 : 899;
            return basePrice + (n * 137 % 2600);
        }

        private static string BuildDescription(string name, string category)
        {
            return name + " from our " + category + " edit. Thoughtfully selected for expressive everyday style, comfort and versatile wardrobe pairing.";
        }

        private static List<CatalogGroup> BuildCatalog()
        {
            return new List<CatalogGroup>
            {
                new CatalogGroup { Category="Women", Sizes=new[]{"XS","S","M","L","XL"}, Colors=new[]{"Black","Ivory","Coral","Sage","Blue"}, Image="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900", Products=new[]{
                    "Sculpted Linen Blazer","Everyday Ribbed Tank","Satin Evening Top","Relaxed Wide-Leg Trousers","Weekend Denim Jacket","Soft Knit Cardigan","Floral Midi Dress","Tailored Co-ord Set","Classic Wrap Dress","Textured Cotton Shirt","Pleated Midi Skirt","Essential Straight Jeans","Cropped Utility Jacket","Draped Occasion Blouse","Luxe Lounge Set","Printed Summer Maxi","Structured Waistcoat","Soft Touch Leggings","Button-Front Mini Dress","Statement Knit Sweater" } },
                new CatalogGroup { Category="Men", Sizes=new[]{"S","M","L","XL","XXL"}, Colors=new[]{"Black","White","Navy","Olive","Stone"}, Image="https://images.unsplash.com/photo-1516257984-b1b4d707412e?w=900", Products=new[]{
                    "Premium Heavyweight Tee","Oxford Button-Down Shirt","Relaxed Chino Trousers","Classic Denim Overshirt","Textured Polo Shirt","Tailored Casual Blazer","Everyday Crew Sweatshirt","Straight Fit Jeans","Lightweight Bomber Jacket","Linen Resort Shirt","Utility Cargo Pants","Merino Blend Sweater","Minimal Track Jacket","Smart Casual Shirt","Weekend Drawstring Shorts","Zip-Neck Knit Top","Heritage Check Shirt","Performance Training Tee","Relaxed Fit Hoodie","Modern Pleated Trousers" } },
                new CatalogGroup { Category="Footwear", Sizes=new[]{"6","7","8","9","10","11"}, Colors=new[]{"White","Black","Tan","Grey"}, Image="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900", Products=new[]{
                    "Retro Court Sneakers","Everyday Running Shoes","Leather Minimal Trainers","City Walk Loafers","Classic Canvas High-Tops","Chunky Street Sneakers","Suede Weekend Shoes","Minimal Slide Sandals","Everyday Leather Flats","Sport Performance Runners","Urban High-Top Sneakers","Soft Strap Sandals","Classic Penny Loafers","Trail Ready Trainers","Statement Platform Sneakers" } },
                new CatalogGroup { Category="Kids", Sizes=new[]{"2-3Y","4-5Y","6-7Y","8-9Y"}, Colors=new[]{"Blue","Pink","Yellow","Green"}, Image="https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900", Products=new[]{
                    "Mini Explorer Hoodie","Playday Cotton Tee","Rainbow Stripe Dress","Everyday Jogger Set","Little Weekend Shorts","Soft Knit Cardigan Kids","Graphic Adventure Tee","Easy Pull-On Trousers","Printed Party Dress","Cozy Zip Sweatshirt" } },
                new CatalogGroup { Category="Accessories", Sizes=new[]{"One Size"}, Colors=new[]{"Black","Tan","Silver","Gold","Multi"}, Image="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=900", Products=new[]{
                    "Sculptural Metal Earrings","Everyday Leather Belt","Layered Chain Necklace","Classic Square Sunglasses","Minimal Analog Watch","Soft Knit Beanie","Textured Baseball Cap","Silk Touch Scarf","Statement Cuff Bracelet","Everyday Card Holder","Modern Hair Clip Set","Compact Travel Umbrella","Premium Leather Wallet","Pearl Detail Earrings","Minimal Pendant Necklace" } },
                new CatalogGroup { Category="Beauty & Care", Sizes=new[]{"One Size"}, Colors=new[]{"Natural","Rose","Clear"}, Image="https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=900", Products=new[]{
                    "Daily Glow Face Serum","Hydrating Body Lotion","Velvet Matte Lip Colour","Gentle Foaming Cleanser","Nourish Hair Mask","Daily SPF Moisturizer","Rosewater Face Mist","Soft Touch Hand Cream","Overnight Repair Cream","Fresh Citrus Body Wash" } },
                new CatalogGroup { Category="Bags & Luggage", Sizes=new[]{"One Size"}, Colors=new[]{"Black","Tan","Cream","Olive"}, Image="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900", Products=new[]{
                    "Everyday Structured Tote","Compact Crossbody Bag","Weekend Travel Duffel","Minimal Laptop Backpack","Soft Shoulder Bag" } },
                new CatalogGroup { Category="Activewear", Sizes=new[]{"XS","S","M","L","XL"}, Colors=new[]{"Black","Lilac","Sage","Blue"}, Image="https://images.unsplash.com/photo-1518611012118-696072aa579a?w=900", Products=new[]{
                    "Studio Sculpt Leggings","Breathable Training Tee","High Support Sports Bra","Lightweight Running Shorts","Performance Zip Jacket" } }
            };
        }
    }
}
