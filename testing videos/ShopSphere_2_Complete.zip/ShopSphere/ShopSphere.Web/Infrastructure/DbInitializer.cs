using System;
using System.Data.Entity;
using System.Linq;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Web.Infrastructure
{
    public class DbInitializer : CreateDatabaseIfNotExists<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext db)
        {
            if (!db.Categories.Any())
            {
                var women = new Category { Name = "Women" };
                var men = new Category { Name = "Men" };
                var accessories = new Category { Name = "Accessories" };
                db.Categories.Add(women); db.Categories.Add(men); db.Categories.Add(accessories);
                db.SaveChanges();

                var p1 = new Product { Name = "Classic Oversized Shirt", Description = "Relaxed-fit everyday shirt in a soft cotton blend.", Price = 1499m, CategoryId = women.CategoryId, IsFeatured = true, IsActive = true, ImageUrl = "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=700" };
                var p2 = new Product { Name = "Minimal Cotton T-Shirt", Description = "A clean everyday essential with a comfortable fit.", Price = 899m, CategoryId = men.CategoryId, IsFeatured = true, IsActive = true, ImageUrl = "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=700" };
                var p3 = new Product { Name = "Everyday Canvas Tote", Description = "A versatile carry-all for everyday use.", Price = 699m, CategoryId = accessories.CategoryId, IsFeatured = true, IsActive = true, ImageUrl = "https://images.unsplash.com/photo-1544816155-12df9643f363?w=700" };
                db.Products.Add(p1); db.Products.Add(p2); db.Products.Add(p3); db.SaveChanges();
                db.ProductVariants.Add(new ProductVariant { ProductId = p1.ProductId, Size = "M", Color = "Beige", StockQuantity = 12 });
                db.ProductVariants.Add(new ProductVariant { ProductId = p1.ProductId, Size = "L", Color = "Beige", StockQuantity = 8 });
                db.ProductVariants.Add(new ProductVariant { ProductId = p2.ProductId, Size = "M", Color = "Black", StockQuantity = 20 });
                db.ProductVariants.Add(new ProductVariant { ProductId = p3.ProductId, Size = "One Size", Color = "Natural", StockQuantity = 15 });
                db.SaveChanges();
            }

            if (!db.Users.Any(u => u.Role == "Admin"))
            {
                db.Users.Add(new User {
                    FullName = "ShopSphere Administrator",
                    Email = "admin@shopsphere.local",
                    PasswordHash = PasswordHasher.Hash("ChangeMe123!"),
                    Role = "Admin",
                    IsActive = true
                });
                db.SaveChanges();
            }
            base.Seed(db);
        }
    }
}
