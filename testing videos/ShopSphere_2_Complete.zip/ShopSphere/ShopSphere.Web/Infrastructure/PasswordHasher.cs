using System;
using System.Security.Cryptography;

namespace ShopSphere.Web.Infrastructure
{
    public static class PasswordHasher
    {
        // PBKDF2-HMAC-SHA256, random 16-byte salt, 100,000 iterations.
        public static string Hash(string password)
        {
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var derive = new Rfc2898DeriveBytes(password, salt, 100000, HashAlgorithmName.SHA256))
            {
                byte[] key = derive.GetBytes(32);
                return "100000:" + Convert.ToBase64String(salt) + ":" + Convert.ToBase64String(key);
            }
        }

        public static bool Verify(string password, string stored)
        {
            try
            {
                var parts = stored.Split(':');
                int iterations = Int32.Parse(parts[0]);
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] expected = Convert.FromBase64String(parts[2]);
                using (var derive = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
                {
                    byte[] actual = derive.GetBytes(expected.Length);
                    int diff = 0;
                    for (int i = 0; i < actual.Length; i++) diff |= actual[i] ^ expected[i];
                    return diff == 0;
                }
            }
            catch { return false; }
        }
    }
}
