using System;
using System.Web;
using System.Web.Mvc;

namespace ShopSphere.Web.Infrastructure
{
    public class ShopAuthorizeAttribute : AuthorizeAttribute
    {
        private readonly string _role;
        public ShopAuthorizeAttribute(string role = null) { _role = role; }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var userId = httpContext.Session["UserId"];
            var role = httpContext.Session["UserRole"] as string;
            if (userId == null) return false;
            return String.IsNullOrEmpty(_role) || String.Equals(role, _role, StringComparison.OrdinalIgnoreCase);
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectResult("~/Account/Login");
        }
    }
}
