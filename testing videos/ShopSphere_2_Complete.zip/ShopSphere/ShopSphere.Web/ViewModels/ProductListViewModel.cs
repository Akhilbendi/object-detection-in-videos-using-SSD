using System.Collections.Generic;
using ShopSphere.Domain.Entities;
namespace ShopSphere.Web.ViewModels
{
    public class ProductListViewModel
    {
        public string Search { get; set; }
        public int? CategoryId { get; set; }
        public string Sort { get; set; }
        public IList<Product> Products { get; set; }
        public IList<Category> Categories { get; set; }
    }
}
