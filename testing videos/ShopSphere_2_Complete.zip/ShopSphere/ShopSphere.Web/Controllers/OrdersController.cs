using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize]
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private int UserId { get { return (int)Session["UserId"]; } }

        public ActionResult Index()
        {
            return View(db.Orders.Where(o => o.UserId == UserId).OrderByDescending(o => o.CreatedUtc).ToList());
        }

        public ActionResult Details(int id)
        {
            var order = db.Orders.Include("Items").SingleOrDefault(o => o.OrderId == id && o.UserId == UserId);
            if (order == null) return HttpNotFound();
            ViewBag.Payment = db.Payments.SingleOrDefault(p => p.OrderId == id);
            return View(order);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Cancel(int id, string reason)
        {
            using (var tx = db.Database.BeginTransaction())
            {
                var order = db.Orders.Include("Items.ProductVariant").SingleOrDefault(o => o.OrderId == id && o.UserId == UserId);
                if (order == null) return HttpNotFound();
                if (order.Status != OrderStatus.Pending && order.Status != OrderStatus.Confirmed && order.Status != OrderStatus.Processing)
                {
                    TempData["OrderMessage"] = "This order can no longer be cancelled.";
                    return RedirectToAction("Details", new { id = id });
                }
                foreach (var item in order.Items)
                    if (item.ProductVariant != null) item.ProductVariant.StockQuantity += item.Quantity;
                order.Status = OrderStatus.Cancelled;
                var payment = db.Payments.SingleOrDefault(p => p.OrderId == id);
                if (payment != null && payment.Status == PaymentStatus.Successful) payment.Status = PaymentStatus.Refunded;
                db.SaveChanges();
                tx.Commit();
            }
            TempData["OrderMessage"] = "Your order has been cancelled. Stock has been returned to inventory. Simulated payment refund status has been updated where applicable.";
            return RedirectToAction("Details", new { id = id });
        }
    }
}
