using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize]
    public class CheckoutController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private int UserId { get { return (int)Session["UserId"]; } }

        public ActionResult Index()
        {
            var cart = db.Carts.Include("Items.ProductVariant.Product").SingleOrDefault(c => c.UserId == UserId);
            if (cart == null || !cart.Items.Any()) return RedirectToAction("Index", "Cart");
            return View(new CheckoutViewModel { Items = cart.Items.ToList(), Address = new Address() });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult PlaceOrder(CheckoutViewModel model)
        {
            var cart = db.Carts.Include("Items.ProductVariant.Product").SingleOrDefault(c => c.UserId == UserId);
            if (cart == null || !cart.Items.Any()) return RedirectToAction("Index", "Cart");
            if (model.Address == null) ModelState.AddModelError("", "Delivery address is required.");
            if (!ModelState.IsValid) { model.Items = cart.Items.ToList(); return View("Index", model); }

            using (var tx = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (var item in cart.Items)
                        if (item.Quantity > item.ProductVariant.StockQuantity)
                            throw new InvalidOperationException("Stock changed. Please review your cart.");

                    model.Address.UserId = UserId;
                    db.Addresses.Add(model.Address);
                    db.SaveChanges();

                    decimal subtotal = cart.Items.Sum(i => i.Quantity * i.ProductVariant.Product.Price);
                    var order = new Order {
                        UserId = UserId, AddressId = model.Address.AddressId,
                        OrderNumber = "SS-" + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6).ToUpperInvariant(),
                        Subtotal = subtotal, Shipping = subtotal >= 2000m ? 0m : 99m,
                        Total = subtotal + (subtotal >= 2000m ? 0m : 99m),
                        Status = OrderStatus.Confirmed
                    };
                    db.Orders.Add(order);
                    db.SaveChanges();

                    foreach (var item in cart.Items.ToList())
                    {
                        var variant = item.ProductVariant;
                        variant.StockQuantity -= item.Quantity;
                        db.OrderItems.Add(new OrderItem {
                            OrderId = order.OrderId, ProductVariantId = variant.ProductVariantId,
                            ProductNameSnapshot = variant.Product.Name, SizeSnapshot = variant.Size,
                            ColorSnapshot = variant.Color, Quantity = item.Quantity,
                            UnitPrice = variant.Product.Price
                        });
                        db.CartItems.Remove(item);
                    }

                    db.Payments.Add(new Payment {
                        OrderId = order.OrderId, Method = "Simulated",
                        Status = PaymentStatus.Successful,
                        TransactionReference = "SIM-" + Guid.NewGuid().ToString("N").Substring(0, 12).ToUpperInvariant()
                    });
                    db.SaveChanges();
                    tx.Commit();
                    return RedirectToAction("Confirmation", new { id = order.OrderId });
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    ModelState.AddModelError("", ex.Message);
                    model.Items = cart.Items.ToList();
                    return View("Index", model);
                }
            }
        }

        public ActionResult Confirmation(int id)
        {
            var order = db.Orders.Include("Items").SingleOrDefault(o => o.OrderId == id && o.UserId == UserId);
            if (order == null) return HttpNotFound();
            ViewBag.Payment = db.Payments.SingleOrDefault(p => p.OrderId == id);
            return View(order);
        }
    }

    public class CheckoutViewModel
    {
        public System.Collections.Generic.IList<CartItem> Items { get; set; }
        [System.ComponentModel.DataAnnotations.Required] public Address Address { get; set; }
    }
}
