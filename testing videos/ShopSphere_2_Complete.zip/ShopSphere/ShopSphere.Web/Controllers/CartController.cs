using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize]
    public class CartController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private int UserId { get { return (int)Session["UserId"]; } }

        public ActionResult Index()
        {
            var cart = db.Carts.Include("Items.ProductVariant.Product").SingleOrDefault(c => c.UserId == UserId);
            if (cart == null) { cart = new Cart { UserId = UserId }; db.Carts.Add(cart); db.SaveChanges(); }
            return View(cart);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Add(int variantId, int quantity = 1)
        {
            if (quantity < 1 || quantity > 10) return new HttpStatusCodeResult(400);
            var variant = db.ProductVariants.Find(variantId);
            if (variant == null || variant.StockQuantity < quantity) { TempData["Error"] = "Selected size/colour is unavailable."; return RedirectToAction("Index", "Product"); }
            var cart = db.Carts.SingleOrDefault(c => c.UserId == UserId);
            if (cart == null) { cart = new Cart { UserId = UserId }; db.Carts.Add(cart); db.SaveChanges(); }
            var item = db.CartItems.SingleOrDefault(i => i.CartId == cart.CartId && i.ProductVariantId == variantId);
            if (item == null) db.CartItems.Add(new CartItem { CartId = cart.CartId, ProductVariantId = variantId, Quantity = quantity });
            else if (item.Quantity + quantity <= variant.StockQuantity) item.Quantity += quantity;
            else { TempData["Error"] = "Not enough stock."; return RedirectToAction("Index", "Product"); }
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Update(int itemId, int quantity)
        {
            var item = db.CartItems.Include("ProductVariant").Include("Cart").SingleOrDefault(i => i.CartItemId == itemId && i.Cart.UserId == UserId);
            if (item != null)
            {
                if (quantity <= 0) db.CartItems.Remove(item);
                else if (quantity <= item.ProductVariant.StockQuantity) item.Quantity = quantity;
                else TempData["Error"] = "Requested quantity exceeds available stock.";
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Remove(int itemId)
        {
            var item = db.CartItems.SingleOrDefault(i => i.CartItemId == itemId && i.Cart.UserId == UserId);
            if (item != null) { db.CartItems.Remove(item); db.SaveChanges(); }
            return RedirectToAction("Index");
        }
    }
}
