using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Web.ViewModels;

namespace ShopSphere.Web.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index(string search, int? categoryId, string sort = "featured")
        {
            var query = db.Products.Include("Category").Where(p => p.IsActive);
            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(p => p.Name.Contains(search) || p.Description.Contains(search) || p.Category.Name.Contains(search));
            if (categoryId.HasValue) query = query.Where(p => p.CategoryId == categoryId.Value);
            switch ((sort ?? "featured").ToLowerInvariant())
            {
                case "price-low": query = query.OrderBy(p => p.Price); break;
                case "price-high": query = query.OrderByDescending(p => p.Price); break;
                case "name": query = query.OrderBy(p => p.Name); break;
                default: query = query.OrderByDescending(p => p.IsFeatured).ThenBy(p => p.Name); break;
            }
            return View(new ProductListViewModel { Search = search, CategoryId = categoryId, Sort = sort, Products = query.ToList(), Categories = db.Categories.OrderBy(c => c.Name).ToList() });
        }
        public ActionResult Details(int id)
        {
            var product = db.Products.Include("Category").Include("Variants").SingleOrDefault(p => p.ProductId == id && p.IsActive);
            if (product == null) return HttpNotFound();
            return View(product);
        }
    }
}
