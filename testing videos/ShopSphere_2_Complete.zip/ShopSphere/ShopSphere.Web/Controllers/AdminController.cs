using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize("Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index()
        {
            ViewBag.ProductCount = db.Products.Count();
            ViewBag.OrderCount = db.Orders.Count();
            ViewBag.CustomerCount = db.Users.Count(u => u.Role == "Customer");
            ViewBag.Revenue = db.Orders.Where(o => o.Status != OrderStatus.Cancelled).Select(o => (decimal?)o.Total).Sum() ?? 0m;
            return View();
        }
        public ActionResult Products() { return View(db.Products.Include("Category").OrderBy(p => p.Name).ToList()); }
        public ActionResult CreateProduct() { ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Name"); return View(); }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult CreateProduct(Product product)
        {
            if (!ModelState.IsValid) { ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Name", product.CategoryId); return View(product); }
            product.IsActive = true; db.Products.Add(product); db.SaveChanges();
            return RedirectToAction("Products");
        }
        public ActionResult EditProduct(int id)
        {
            var product = db.Products.Find(id); if (product == null) return HttpNotFound();
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Name", product.CategoryId); return View(product);
        }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult EditProduct(Product product)
        {
            if (!ModelState.IsValid) { ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "Name", product.CategoryId); return View(product); }
            db.Entry(product).State = System.Data.Entity.EntityState.Modified; db.SaveChanges(); return RedirectToAction("Products");
        }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult ToggleProduct(int id)
        {
            var product = db.Products.Find(id); if (product != null) { product.IsActive = !product.IsActive; db.SaveChanges(); }
            return RedirectToAction("Products");
        }
        public ActionResult Orders()
        {
            return View(db.Orders.Include("User").OrderByDescending(o => o.CreatedUtc).ToList());
        }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult UpdateOrderStatus(int id, OrderStatus status)
        {
            var order = db.Orders.Find(id);
            if (order != null) { order.Status = status; db.SaveChanges(); }
            return RedirectToAction("Orders");
        }

        public ActionResult Customers()
        {
            return View(db.Users.Where(u => u.Role == "Customer").OrderBy(u => u.FullName).ToList());
        }

        public ActionResult Categories()
        {
            return View(db.Categories.OrderBy(c => c.Name).ToList());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult CreateCategory(string name)
        {
            if (!string.IsNullOrWhiteSpace(name) && !db.Categories.Any(c => c.Name == name.Trim()))
            {
                db.Categories.Add(new Category { Name = name.Trim() });
                db.SaveChanges();
            }
            return RedirectToAction("Categories");
        }

        public ActionResult Variants(int productId)
        {
            var product = db.Products.Include("Variants").SingleOrDefault(p => p.ProductId == productId);
            if (product == null) return HttpNotFound();
            return View(product);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult CreateVariant(int productId, string size, string color, int stockQuantity)
        {
            var product = db.Products.Find(productId);
            if (product == null) return HttpNotFound();
            if (string.IsNullOrWhiteSpace(size) || string.IsNullOrWhiteSpace(color) || stockQuantity < 0)
            {
                TempData["AdminError"] = "Enter a size, colour and non-negative stock quantity.";
                return RedirectToAction("Variants", new { productId = productId });
            }
            bool exists = db.ProductVariants.Any(v => v.ProductId == productId && v.Size == size && v.Color == color);
            if (!exists)
            {
                db.ProductVariants.Add(new ProductVariant { ProductId = productId, Size = size.Trim(), Color = color.Trim(), StockQuantity = stockQuantity });
                db.SaveChanges();
            }
            else TempData["AdminError"] = "That size and colour combination already exists.";
            return RedirectToAction("Variants", new { productId = productId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult UpdateVariantStock(int variantId, int stockQuantity)
        {
            var variant = db.ProductVariants.Find(variantId);
            if (variant == null) return HttpNotFound();
            if (stockQuantity >= 0) { variant.StockQuantity = stockQuantity; db.SaveChanges(); }
            return RedirectToAction("Variants", new { productId = variant.ProductId });
        }
    }
}
