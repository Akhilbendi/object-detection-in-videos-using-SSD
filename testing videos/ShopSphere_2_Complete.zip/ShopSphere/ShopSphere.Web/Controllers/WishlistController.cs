using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize]
    public class WishlistController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        private int UserId { get { return (int)Session["UserId"]; } }
        public ActionResult Index() { return View(db.Wishlists.Include("Product").Where(w => w.UserId == UserId).ToList()); }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Add(int productId)
        {
            if (!db.Wishlists.Any(w => w.UserId == UserId && w.ProductId == productId) && db.Products.Any(p => p.ProductId == productId && p.IsActive))
            { db.Wishlists.Add(new Wishlist { UserId = UserId, ProductId = productId }); db.SaveChanges(); }
            return RedirectToAction("Index", "Product");
        }
        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Remove(int id)
        {
            var item = db.Wishlists.SingleOrDefault(w => w.WishlistId == id && w.UserId == UserId);
            if (item != null) { db.Wishlists.Remove(item); db.SaveChanges(); }
            return RedirectToAction("Index");
        }
    }
}
