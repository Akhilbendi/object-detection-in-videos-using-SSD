using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
namespace ShopSphere.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            using (var db = new ApplicationDbContext())
            {
                ViewBag.Categories = db.Categories.OrderBy(c => c.Name).ToList();
                ViewBag.Featured = db.Products.Include("Category").Where(p => p.IsActive && p.IsFeatured).OrderBy(p => p.Name).Take(8).ToList();
            }
            return View();
        }
        public ActionResult About() { ViewBag.Message = "ShopSphere is a fashion e-commerce learning application."; return View(); }
    }
}
