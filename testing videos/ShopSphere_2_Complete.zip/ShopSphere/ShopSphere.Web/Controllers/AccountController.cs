using System.Linq;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        [AllowAnonymous] public ActionResult Register() { return View(); }

        [HttpPost, ValidateAntiForgeryToken, AllowAnonymous]
        public ActionResult Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var email = model.Email.Trim().ToLowerInvariant();
            if (db.Users.Any(u => u.Email == email)) { ModelState.AddModelError("Email", "This email is already registered."); return View(model); }
            var user = new User { FullName = model.FullName.Trim(), Email = email, PasswordHash = PasswordHasher.Hash(model.Password), Role = "Customer" };
            db.Users.Add(user); db.SaveChanges();
            db.Carts.Add(new Cart { UserId = user.UserId }); db.SaveChanges();
            Session["UserId"] = user.UserId; Session["UserName"] = user.FullName; Session["UserRole"] = user.Role;
            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous] public ActionResult Login(string returnUrl) { ViewBag.ReturnUrl = returnUrl; return View(); }

        [HttpPost, ValidateAntiForgeryToken, AllowAnonymous]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid) return View(model);
            var email = model.Email.Trim().ToLowerInvariant();
            var user = db.Users.SingleOrDefault(u => u.Email == email && u.IsActive);
            if (user == null || !PasswordHasher.Verify(model.Password, user.PasswordHash))
            {
                ModelState.AddModelError("", "Invalid email or password."); return View(model);
            }
            Session["UserId"] = user.UserId; Session["UserName"] = user.FullName; Session["UserRole"] = user.Role;
            if (user.Role == "Admin") return RedirectToAction("Index", "Admin");
            if (Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        [ShopAuthorize]
        public ActionResult ChangePassword() { return View(); }

        [HttpPost, ValidateAntiForgeryToken, ShopAuthorize]
        public ActionResult ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            int userId = (int)Session["UserId"];
            var user = db.Users.Find(userId);
            if (user == null || !PasswordHasher.Verify(model.CurrentPassword, user.PasswordHash))
            {
                ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                return View(model);
            }
            user.PasswordHash = PasswordHasher.Hash(model.NewPassword);
            db.SaveChanges();
            TempData["Message"] = "Your password has been changed.";
            return RedirectToAction("ChangePassword");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Logout() { Session.Clear(); Session.Abandon(); return RedirectToAction("Index", "Home"); }
    }

    public class RegisterViewModel
    {
        [System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.StringLength(100)]
        public string FullName { get; set; }
        [System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.EmailAddress]
        public string Email { get; set; }
        [System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.MinLength(8)]
        public string Password { get; set; }
        [System.ComponentModel.DataAnnotations.Compare("Password")]
        public string ConfirmPassword { get; set; }
    }
    public class LoginViewModel
    {
        [System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.EmailAddress]
        public string Email { get; set; }
        [System.ComponentModel.DataAnnotations.Required, System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string Password { get; set; }
    }
}

namespace ShopSphere.Web.Controllers
{
    public class ChangePasswordViewModel
    {
        [System.ComponentModel.DataAnnotations.Required]
        [System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string CurrentPassword { get; set; }

        [System.ComponentModel.DataAnnotations.Required]
        [System.ComponentModel.DataAnnotations.MinLength(8)]
        [System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string NewPassword { get; set; }

        [System.ComponentModel.DataAnnotations.Required]
        [System.ComponentModel.DataAnnotations.Compare("NewPassword")]
        [System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        public string ConfirmNewPassword { get; set; }
    }
}
