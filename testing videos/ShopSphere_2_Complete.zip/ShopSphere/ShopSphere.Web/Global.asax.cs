using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Data.Entity;
using ShopSphere.Data;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            Database.SetInitializer(new DbInitializer());
            using (var db = new ApplicationDbContext())
            {
                db.Database.Initialize(false);
                SampleCatalogSeeder.Seed(db);
            }
        }
    }
}
