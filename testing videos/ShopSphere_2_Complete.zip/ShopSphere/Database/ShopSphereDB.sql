/*
  ShopSphere database setup
  Do not manually create individual tables from this file.
  The application uses Entity Framework 6 Code First with CreateDatabaseIfNotExists.
  On the first application request, EF creates ShopSphereDB, all mapped tables,
  and seeds the starter categories, fashion products, variants and admin account.

  Before first launch:
  1. Ensure the SQL Server service is running.
  2. Ensure the Windows account running Visual Studio can create databases.
  3. Check ShopSphere.Web/Web.config -> ShopSphereConnection.
  4. Run the application (F5). EF creates the database automatically.

  If you prefer creating the empty database yourself, run:
      CREATE DATABASE ShopSphereDB;
  But the application account still needs permissions to create the tables.
*/
IF DB_ID(N'ShopSphereDB') IS NULL
    PRINT 'ShopSphereDB will be created automatically by Entity Framework when the app first runs.';
ELSE
    PRINT 'ShopSphereDB already exists. Ensure it was created by this application and contains the EF schema.';
GO
