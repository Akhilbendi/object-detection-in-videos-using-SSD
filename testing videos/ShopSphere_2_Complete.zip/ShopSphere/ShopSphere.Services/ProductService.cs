using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using ShopSphere.Data;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Services
{
    public class ProductService
    {
        private readonly ApplicationDbContext _db;

        public ProductService() : this(new ApplicationDbContext()) { }
        public ProductService(ApplicationDbContext db) { _db = db; }

        public IList<Product> GetActiveProducts(string search = null)
        {
            var query = _db.Products.Include("Category").Include("Variants").Where(p => p.IsActive);
            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(p => p.Name.Contains(search) || p.Description.Contains(search));
            return query.OrderBy(p => p.Name).ToList();
        }
    }
}
