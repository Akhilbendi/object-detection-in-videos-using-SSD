using System.Data.Entity;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext() : base("ShopSphereConnection") { }

        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductVariant> ProductVariants { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<Wishlist> Wishlists { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<Payment> Payments { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasRequired(p => p.Category).WithMany(c => c.Products).HasForeignKey(p => p.CategoryId).WillCascadeOnDelete(false);
            modelBuilder.Entity<ProductVariant>().HasRequired(v => v.Product).WithMany(p => p.Variants).HasForeignKey(v => v.ProductId);
            modelBuilder.Entity<Cart>().HasRequired(c => c.User).WithMany().HasForeignKey(c => c.UserId).WillCascadeOnDelete(false);
            modelBuilder.Entity<CartItem>().HasRequired(i => i.Cart).WithMany(c => c.Items).HasForeignKey(i => i.CartId);
            modelBuilder.Entity<CartItem>().HasRequired(i => i.ProductVariant).WithMany().HasForeignKey(i => i.ProductVariantId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Wishlist>().HasRequired(w => w.User).WithMany().HasForeignKey(w => w.UserId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Wishlist>().HasRequired(w => w.Product).WithMany().HasForeignKey(w => w.ProductId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Address>().HasRequired(a => a.User).WithMany().HasForeignKey(a => a.UserId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Order>().HasRequired(o => o.User).WithMany().HasForeignKey(o => o.UserId).WillCascadeOnDelete(false);
            modelBuilder.Entity<Order>().HasRequired(o => o.Address).WithMany().HasForeignKey(o => o.AddressId).WillCascadeOnDelete(false);
            modelBuilder.Entity<OrderItem>().HasRequired(i => i.Order).WithMany(o => o.Items).HasForeignKey(i => i.OrderId);
            modelBuilder.Entity<Payment>().HasRequired(p => p.Order).WithMany().HasForeignKey(p => p.OrderId).WillCascadeOnDelete(false);
            modelBuilder.Entity<User>().Property(u => u.Email).IsRequired();
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();
            base.OnModelCreating(modelBuilder);
        }
    }
}
