using System.Data.Entity.Migrations;

namespace ShopSphere.Data.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<ShopSphere.Data.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            MigrationsDirectory = @"Migrations";
        }
    }
}
