using System.Web.Mvc;

namespace ShopSphere.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "ShopSphere is a learning e-commerce application.";
            return View();
        }
    }
}
