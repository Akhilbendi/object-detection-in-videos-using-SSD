using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Web.Infrastructure;

namespace ShopSphere.Web.Controllers
{
    [ShopAuthorize]
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index()
        {
            int userId = (int)Session["UserId"];
            return View(db.Orders.Where(o => o.UserId == userId).OrderByDescending(o => o.CreatedUtc).ToList());
        }
        public ActionResult Details(int id)
        {
            int userId = (int)Session["UserId"];
            var order = db.Orders.Include("Items").Include("Payment").SingleOrDefault(o => o.OrderId == id && o.UserId == userId);
            if (order == null) return HttpNotFound();
            return View(order);
        }
    }
}
