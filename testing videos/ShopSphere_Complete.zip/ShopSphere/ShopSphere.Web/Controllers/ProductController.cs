using System.Linq;
using System.Web.Mvc;
using ShopSphere.Data;
using ShopSphere.Services;
using ShopSphere.Web.ViewModels;

namespace ShopSphere.Web.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductService _products = new ProductService();
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Index(string search, int? categoryId)
        {
            var products = _products.GetActiveProducts(search);
            if (categoryId.HasValue) products = products.Where(p => p.CategoryId == categoryId.Value).ToList();
            return View(new ProductListViewModel { Search = search, Products = products });
        }

        public ActionResult Details(int id)
        {
            var product = db.Products.Include("Category").Include("Variants").SingleOrDefault(p => p.ProductId == id && p.IsActive);
            if (product == null) return HttpNotFound();
            return View(product);
        }
    }
}
