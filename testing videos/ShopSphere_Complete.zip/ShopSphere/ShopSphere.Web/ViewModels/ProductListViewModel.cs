using System.Collections.Generic;
using ShopSphere.Domain.Entities;

namespace ShopSphere.Web.ViewModels
{
    public class ProductListViewModel
    {
        public string Search { get; set; }
        public IList<Product> Products { get; set; }
    }
}
