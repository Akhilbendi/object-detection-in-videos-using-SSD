# ShopSphere – Fashion E-Commerce (ASP.NET MVC 5)

A multi-project C# learning application built with ASP.NET MVC 5, .NET Framework 4.8, Entity Framework 6 and SQL Server.

## Included features

### Customer storefront
- Fashion storefront homepage and responsive Bootstrap layout
- Product catalogue, product detail pages and text search
- Product size/colour variants and stock display
- Customer registration and login
- Session-based customer/admin access
- Shopping cart: add, update quantity and remove
- Wishlist
- Delivery address form and checkout
- Simulated payment (no real payment provider or card data)
- Order confirmation, order history and order details

### Admin
- Admin dashboard with product/order/customer counts and order revenue
- Add and edit products
- Activate/deactivate products
- Manage categories and product size/colour variants and stock\n- View customers\n- View orders and update order status

### Architecture and database
- Four-project Visual Studio solution: Web, Domain, Data, Services
- Entity Framework 6 Code First context and relationships
- Database initializer with sample products and default admin
- SQL Server database created on first run
- PBKDF2 password hashing
- Anti-forgery tokens on state-changing forms

## Prerequisites
- Visual Studio 2022 with **ASP.NET and web development** workload
- .NET Framework 4.8 Developer Pack
- SQL Server 2019 (default instance `.` or update connection string)
- NuGet package restore enabled
- IIS Express (installed with Visual Studio web workload)

## First run
1. Extract the ZIP.
2. Open `ShopSphere.sln` in Visual Studio 2022.
3. Restore NuGet packages (right-click solution → Restore NuGet Packages).
4. Set `ShopSphere.Web` as the startup project if it is not already.
5. Open `ShopSphere.Web/Web.config` and update `ShopSphereConnection` if your SQL Server instance is not `.`.
   - Default: `Data Source=.;Initial Catalog=ShopSphereDB;Integrated Security=True;MultipleActiveResultSets=True`
   - For SQL Express, try `Data Source=.\SQLEXPRESS;Initial Catalog=ShopSphereDB;Integrated Security=True;MultipleActiveResultSets=True`
6. Make sure the Windows account running Visual Studio has permission to create a database.
7. Build the solution (`Ctrl+Shift+B`) and run (F5).
8. On first database access, Entity Framework creates the database, tables and sample catalogue.

Do not manually create a partial database first. The EF initializer is responsible for creating the complete schema.

## Default administrator
- Email: `admin@shopsphere.local`
- Password: `ChangeMe123!`

Change this password before using the application beyond local development. This default is for local learning only.

## Important scope and limitations
- This is a complete learning-project starter with the listed end-to-end flows, not a production-certified commerce platform.
- Payment is simulated and always creates a successful test transaction. No real money is processed.
- Authentication uses a custom session-based implementation with PBKDF2 password hashing for learning. A production system should use ASP.NET Identity, hardened cookie authentication, account lockout, password reset, email verification, CSRF/security review and robust authorization.
- Product image URLs use externally hosted sample images; replace them with images you own or are licensed to use.
- The first-run database initializer seeds sample products and an admin account. It does not seed sample customer orders.
- No live shipping provider, tax engine, email/SMS service, or real payment gateway is connected.

## GitHub
A `.gitignore` is included. After opening and testing locally:
```bash
git init
git add .
git commit -m "Initial ShopSphere e-commerce application"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ShopSphere.git
git push -u origin main
```
