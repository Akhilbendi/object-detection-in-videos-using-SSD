# ShopSphere 2.0 — Fashion E-Commerce Learning Application

## Technology
- Visual Studio 2022, C# / ASP.NET MVC 5, .NET Framework 4.8
- Entity Framework 6.4.4
- SQL Server LocalDB (`(LocalDB)\MSSQLLocalDB`)
- Bootstrap 5, responsive CSS, lightweight JavaScript motion

## Open
1. Extract the archive.
2. Open `ShopSphere\ShopSphere.sln` in Visual Studio 2022.
3. Restore NuGet packages.
4. Ensure the .NET Framework 4.8 Developer Pack is installed.
5. Set `ShopSphere.Web` as startup project.
6. Build the solution.
7. Run with Ctrl+F5.

The Web.config connection string points only to the user's LocalDB instance and the `ShopSphereDB` catalog. It does not point to the organisation's SQL Server instance.

## Database and sample catalogue
The application startup runs `SampleCatalogSeeder` against the configured ShopSphereDB database. It adds 8 categories and 100 unique sample products with stock variants, while checking for existing category/product names to avoid duplicating the catalogue on subsequent launches. The original initial database initializer remains in place for a first-time local database.

If an existing ShopSphereDB has already been created with EF6 migrations, keep that database. The seeder fills the catalogue at application startup; it does not drop or recreate the database.

## Admin account
Email: `admin@shopsphere.local`
Password: `ChangeMe123!`
Change the default password after first login. If the account was not created by the first-time initializer, use the registration/admin setup process approved for your local development environment.

## Features
- Vibrant fashion storefront, animated hero, category mega menu and responsive layout
- 8 categories and 100 sample products
- Product search, category filtering and price/name sorting
- Product detail, variants, stock-aware cart, wishlist and simulated checkout
- Order history and details; customer cancellation while Pending, Confirmed or Processing
- Cancellation restores stock and marks a successful simulated payment as Refunded
- Existing admin product, inventory and order screens

## Important notes
- Payment processing is simulated only. No real payment gateway or card data is used.
- Product imagery uses externally hosted Unsplash images and therefore requires internet access to load those images.
- This is an educational starter application, not production-certified. Before production use, replace custom session authentication with ASP.NET Identity or equivalent hardened auth, add robust audit logging, rate limiting, email verification, password reset, security review, accessibility testing, and real payment provider integration.
- This package was structurally checked, but not compiled or run on your Windows PC. Build and test in Visual Studio; resolve any machine-specific NuGet/IIS Express issues before deployment.


### Category imagery update

Homepage category photographs are now mapped by category name rather than array position. This prevents the alphabetical order returned by SQL Server from shifting images onto unrelated categories. The category images are externally hosted by Unsplash and require an internet connection in the browser.
